# Changelog

## [1.0.0] - 2020-09-22
###Added
- Added confirmation dialog when user pressed on Apply/Revert button on the Sprite Editor Window. This can be enabled/disabled in Preferences

## [1.0.0] - 2019-01-25
###Added
- This is the first release of Sprite Editor, as a Package
