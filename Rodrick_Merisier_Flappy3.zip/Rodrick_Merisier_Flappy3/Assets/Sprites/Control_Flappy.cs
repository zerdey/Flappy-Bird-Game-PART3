using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlappyController : MonoBehaviour
{
    public float horizontalSpeed = 5f; // Vitesse de déplacement horizontal
    public float verticalSpeed = 8f;   // Vitesse de déplacement vertical
    public float gravity = 20f;         // Gravité pour simuler la chute
     public Sprite spriteNormal;
    public Sprite spriteBlesse; // Déclarer la variable spriteBlesse
    


   

   
    // Autres méthodes et variables de classe...


    public SpriteRenderer spriteRenderer;

    private Rigidbody2D rb;

    
    void Start()
    {
       rb = GetComponent<Rigidbody2D>(); // Obtenez la référence au composant Rigidbody2D
    spriteRenderer = GetComponent<SpriteRenderer>(); // Obtenez la référence au composant SpriteRenderer

    

    }

    // Update is called once per frame
    void Update()
    {
    

        // Déplacement vertical
        if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
        {
            rb.velocity = new Vector2(rb.velocity.x, verticalSpeed);
        }

        // Appliquer la gravité
        rb.velocity += new Vector2(0, -gravity * Time.deltaTime);
    }
        
      void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Colonne"))
        {
            
            GetComponent<SpriteRenderer>().sprite = spriteBlesse;



           
            Debug.Log("Flappy a touché une colonne !");
        }
        else if (collision.gameObject.CompareTag("PieceOr"))
        {
            collision.gameObject.SetActive(false); // Désactive la pièce d'or
            Debug.Log("Flappy a touché une pièce d'or !");
            StartCoroutine(ReactivePieceOr(collision.gameObject, 6f)); // Réactive la pièce d'or après 3 secondes
        }
        else if (collision.gameObject.CompareTag("PackVie"))
        {
            collision.gameObject.SetActive(false); // Désactive le pack de vie
             GetComponent<SpriteRenderer>().sprite = spriteNormal;
            Debug.Log("Flappy a touché un pack de vie !");
            StartCoroutine(ReactivePackVie(collision.gameObject, 5f)); // Réactive le pack de vie après 5 secondes
        }
        else if (collision.gameObject.CompareTag("Champignon"))
        {
            collision.gameObject.SetActive(false); // Désactive le champignon
            Debug.Log("Flappy a touché un champignon !");
            float tailleMax = 2.0f; // Définissez la taille maximale souhaitée
            StartCoroutine(GrossirFlappy(3f, 0.1f, tailleMax)); // Appel de la méthode avec les trois arguments requis
            StartCoroutine( ReactiveChampignon(collision.gameObject, 5f)); // Réactive le pack de vie après 5 secondes
            
        }
    }

    IEnumerator ReactivePieceOr(GameObject pieceOr, float delay)
    {
        yield return new WaitForSeconds(delay);
        pieceOr.SetActive(true);
        // Modifier la position verticale aléatoirement
        pieceOr.transform.position = new Vector3(pieceOr.transform.position.x, Random.Range(-2f, 2f), pieceOr.transform.position.z);
    }

    IEnumerator ReactivePackVie(GameObject packVie, float delay)
    {
        yield return new WaitForSeconds(delay);
        packVie.SetActive(true);
        
    }

    IEnumerator GrossirFlappy(float duration, float grossissement, float tailleMax)
{
    float originalScale = transform.localScale.x;
    float timer = 0f;

    // Grossissement de Flappy Bird
    while (timer < duration)
    {
        timer += Time.deltaTime;

        // Calcul du grossissement par frame pour limiter le taux de grossissement
        float grossissementFrame = grossissement * Time.deltaTime;
        transform.localScale += new Vector3(grossissementFrame, grossissementFrame, 0f);

        // Vérifier si la taille dépasse la taille maximale
        if (transform.localScale.x > tailleMax)
        {
            transform.localScale = new Vector4(tailleMax, tailleMax, 10f); // Limiter la taille maximale
            break; // Sortir de la boucle si la taille maximale est atteinte
        }

        yield return null;
    }

    // Maintenir la taille pendant un certain temps
    timer = 0f;
    while (timer < 7f) // Maintenir la taille pendant 7 secondes
    {
        timer += Time.deltaTime;
        yield return null;
    }

    // Rétablir la taille originale de Flappy
    transform.localScale = new Vector3(originalScale, originalScale, 1f);
}
//Reactivation du Champignon lorsque récolté
IEnumerator ReactiveChampignon(GameObject champignon, float delay)
    {
        yield return new WaitForSeconds(delay);
        champignon.SetActive(true);
        champignon.transform.position = new Vector3(champignon.transform.position.x, Random.Range(-2f, 2f), champignon.transform.position.z);
       
    }

    

}


    

