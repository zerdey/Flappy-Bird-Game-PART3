using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{


    public float vitesse;   //CLASSE "Public" veu t dire que tout le monde a accès a la vitesse, même par exemple les ennemis
    public float positionDebut;
    public float positionFin;
    public float deplacementAleatoire;  
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x < positionFin){

            transform.position = new Vector2(positionDebut, Random.Range(-deplacementAleatoire, deplacementAleatoire));


        }
        transform.Translate(vitesse, 0, 0);

        

       

        
           

        
          
        
        
        
    }
}
